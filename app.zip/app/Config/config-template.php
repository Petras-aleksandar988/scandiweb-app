<?php
$config = [
    'servername' => getenv('DB_SERVERNAME'),
    'db_username' => getenv('DB_USERNAME'),
    'db_password' => getenv('DB_PASSWORD'),
    'database_name' => getenv('DB_NAME'),
];